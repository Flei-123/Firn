s route: reference counting plus a retrofitted cycle collector -- more work, not less |
| "**Inheritance** deliberately left out" | **single inheritance for `gc class`** (4.4) | The DOM *is* an inheritance hierarchy (`Node`->`Element`->`HTMLElement`->...) and is described that way normatively in Web IDL. Rebuilding it with composition costs more than it saves |
| "References are **always** second class" | Second class stays the **default**; `Gc[T]` and `Rc[T]` are **first-class** pointers (3.2) | Second-class references solve the lifetime problem elegantly, but in principle they cannot express a cyclic graph. That is exactly what the DOM needs |
| "A **WASM backend** in v0.6, aarch64 in v0.5" | both **postponed, without a date** (10.5) | `FIRN-ANFORDERUNGEN.md` 11 makes it explicit: the browser needs neither a WASM nor an aarch64 backend. WASM *execution* in the browser is an interpreter written in Firn, not a compiler backend. That relieves the scope considerably |

Newly added: 8 (strings, including **WTF-16**), 9 (**constant time** for
crypto), 5.3 (**unwinding/exceptions** for JS semantics), 6.4 (compile-time code
generation), 10.3 (the performance target of **<= 2x Rust**), 16 (traceability
from requirement to section).

Unchanged: the profiles (2), error handling through result types as the normal
route (5.1), `comptime` instead of a macro language (6), no LLVM in the
bootstrap path (10.2), the bootstrap stages (11), and the state of the stage 0
implementation (14).

### v0.1 (2026-08-13) -- first version
A language for kernels and applications, the prototype `firnc0` built and tested.

---

## 0. Why a language of our own at all

Osum is written in Rust today. That works, but it produces a dependency that
Justin does not want in the long run: Rust decides what the kernel may do (Rust
editions, `no_std` limits, LLVM target support, compiler bugs, project politics).
Whoever builds an operating system of their own but obtains the compiler from
others does not really own their system -- they rent it.

Since the browser decision the stakes are higher. Firn has to carry not only a
kernel but **half a million lines of browser engine**. That is the hardest test
there is for a language -- and at the same time the chance for Firn to grow up
along the way. A language design mistake costs not weeks but years in this
situation. That is why this document has become more detailed and decides more
than would be necessary for a kernel alone.

**Honesty up front:** this is a decade-long project. Rust took 9 years to reach
1.0, Zig is at 0.16 after 11 years and still not stable. This document describes
the *goal*; the accompanying compiler implements the section marked in 14 -- but
that part for real, all the way to a running binary.

---

## 1. Guiding principles

1. **Nothing happens hidden.** No implicit allocation, no implicit type
   conversions, no operator overloading, no hidden function calls.
2. **One language, two profiles.** Kernel code and applic